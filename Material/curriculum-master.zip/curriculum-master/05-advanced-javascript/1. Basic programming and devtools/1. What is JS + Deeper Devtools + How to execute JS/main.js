class Main {
	execute(){
		//this is one comment
		//your code
		console.log("Hello world");
	}
}
new Main().execute();