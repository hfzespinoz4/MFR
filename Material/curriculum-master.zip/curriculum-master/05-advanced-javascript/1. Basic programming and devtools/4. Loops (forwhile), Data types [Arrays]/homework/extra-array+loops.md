### Exercise 1 - Fill and Print an array

Write a program that reads in 10 numbers from the keyboard storing them in an array.
Once they are all read in, print them to the screen.

### Exercise 2 - Reverse

Write a program that reads in 10 numbers from the keyboard storing them in an array.
Then print out the same integers in reverse order of input.

### Exercise 3 - Sum all content of an array

Write a program to sum values of an array.

### Exercise 4 - Find value

Write a program to find the "tomato" value in this array

```javascript
["home","mobile","screen","curriculum","tomato","water melon"]
```

### Exercise 4 - Average

Write program to calculate the average value of array elements.

### Exercise 5 - Remove

Write a program to remove a specific element from an array.

### Exercie 6 find maximun values

Write a program to find the maximum value of an array