# Homework

Presenting with alert

- The idea of this exercise is to show an alert message in the browser and that, when we give it to accept, another one appears and so on up to three messages. As an idea you can put something like the following:
```
     Message 1: "Hello my name is ____"

     Message 2: "I was born the ____ of ____, in ____"

     Message 3: "I like ____ and ____"l use alert as we have seen in the previous examples.
```

### Details to be considered
    - first you can do it directly in the html but ideally you work this exercise by running the javascript in a separate file.
    - you should use the template to execute your javascript code.


```javascript
function Main(){
	execute(){
		// JavaScript goes here
		console.log("Hello world");
	}
}
new Main().execute();
```

[template](https://gist.github.com/jonayGodoy/5b2d537ba413809d47888b2a907a879e)
