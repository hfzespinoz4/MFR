The original plan was:

* Basic programming and devtools
	1. What is JS + Deeper Devtools + How to execute JS
	2. Variables (var, const, let) + Variable typing + Operadores
	3. Conditional operators + Case statements, Data types [Bools]
	4.1 Loops (forwhile), Data types [Arrays, Objects]
	4.2 Loops (forwhile), Data types [Arrays, Objects]
	5.1 Functions + review of loops, conditionals, and vars
	5.2 Functions + review of loops, conditionals, and vars
	5.3 Functions + review of loops, conditionals, and vars
	6. Object Oriented Programming + Small project

But the plan has changed a bit. So don't trust this file atm. :wink:
