class Main {
	execute(){
		//this is one comment
		//your code
		alert("Third way | Good way");
	}
}
new Main().execute();